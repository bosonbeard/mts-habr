<?php
// Heading
$_['heading_title']    = 'MTS Exolve send SMS';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified show menu module!';
$_['text_edit']        = 'Edit Show Menu Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_api_token']  = 'MTS Exolve API Key';
$_['entry_api_phone']  = 'MTS Exolve sender phone';
$_['entry_text']       = 'SMS text template';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify this module!';
$_['error_api_token']  = 'MTS Exolve API Key Required';
$_['error_api_phone']  = 'MTS Exolve sender phone Required';

